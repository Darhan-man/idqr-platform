﻿# IDQR — Панель Управления

## 📦 Установка

1. Установите зависимости:
```bash
pip install -r requirements.txt

